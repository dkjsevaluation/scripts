#' dkjslama Pacakge
#'
#' Downloads Lamapoll data throught their API.
#'
#' @docType package
#'
#' @author Alexander Wedel \email(alexander.wedel@dkjs.de)
#'
#' @name dkjslama_1.0
NULL
